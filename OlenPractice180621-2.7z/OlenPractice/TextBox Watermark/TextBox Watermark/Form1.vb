﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Threading

Public Class Form1
    'Dim JobThread As System.Threading.ThreadPool

    Private Sub Watermark1_TextChanged(sender As Object, e As EventArgs) Handles Watermark1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf DataDownload), Watermark1.Text)
    End Sub

    Private Sub DataDownload(StockNum As String)
        Dim Year As Int32 = Now.Year - 10
        Dim Month As Int32 = 1

        Do While Year <= Now.Year
            If Year = Now.Year Then
                Do While Month < Now.Month
                    Dim tmpUri As String = "http://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date=" + Year.ToString + Month.ToString("D2") + "01&stockNo=" + StockNum
                    Dim webRqst As HttpWebRequest = HttpWebRequest.CreateHttp(tmpUri)
                    Dim webRspnd As HttpWebResponse = DirectCast(webRqst.GetResponse(), HttpWebResponse)
                    If webRspnd.StatusCode = HttpStatusCode.OK Then
                        Dim tmpStream As Stream = webRspnd.GetResponseStream()
                        'Dim buffer(tmpStream.Length - 1) As Byte
                        'tmpStream.Read(buffer, 0, buffer.Count())
                        Dim SR As String = New StreamReader(tmpStream).ReadToEnd()
                        'Dim saveFile As FileStream = File.Open("D:\StockData\" + Watermark1.Text + ".txt", FileMode.OpenOrCreate, FileAccess.ReadWrite)
                        If Dir("D:\StockData\", vbDirectory) = "" Then
                            MkDir("D:\StockData\")       '也可以用→FileIO.FileSystem.CreateDirectory("D:\StockData\")
                        End If
                        File.AppendAllText("D:\StockData\" + StockNum + ".txt", SR)
                        'saveFile.Write(buffer, 0, buffer.Count())
                        tmpStream.Dispose()
                        'saveFile.Dispose()
                    End If
                    Month = Month + 1
                    System.Threading.Thread.Sleep(5000)
                Loop
            Else
                Do While Month <= 12
                    Dim tmpUri As String = "http://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date=" + Year.ToString + Month.ToString("D2") + "01&stockNo=" + StockNum
                    Dim webRqst As HttpWebRequest = HttpWebRequest.CreateHttp(tmpUri)
                    Dim webRspnd As HttpWebResponse = DirectCast(webRqst.GetResponse(), HttpWebResponse)
                    If webRspnd.StatusCode = HttpStatusCode.OK Then
                        Dim tmpStream As Stream = webRspnd.GetResponseStream()
                        'Dim buffer(tmpStream.Length - 1) As Byte
                        'tmpStream.Read(buffer, 0, buffer.Count())
                        Dim SR As String = New StreamReader(tmpStream).ReadToEnd()
                        'Dim saveFile As FileStream = File.Open("D:\StockData\" + Watermark1.Text + ".txt", FileMode.OpenOrCreate, FileAccess.ReadWrite)
                        If Dir("D:\StockData\", vbDirectory) = "" Then
                            MkDir("D:\StockData\")       '也可以用→FileIO.FileSystem.CreateDirectory("D:\StockData\")
                        End If
                        File.AppendAllText("D:\StockData\" + StockNum + ".txt", SR)
                        'saveFile.Write(Buffer, 0, Buffer.Count())
                        tmpStream.Dispose()
                        'saveFile.Dispose()
                    End If
                    Month = Month + 1
                    System.Threading.Thread.Sleep(5000)
                Loop
            End If
            Month = 1
            Year = Year + 1
        Loop
    End Sub
End Class
